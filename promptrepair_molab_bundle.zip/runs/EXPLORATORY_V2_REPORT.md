# Exploratory v2 result

**Scope:** post-hoc exploratory comparison on 12 reviewed synthetic cases. Report raw counts only. Keep this result separate from the frozen primary study; it does not support general claims.

| Arm | Correct records | Valid JSON | Valid schema |
| --- | ---: | ---: | ---: |
| Oracle baseline | 11/12 | 12/12 | 12/12 |
| Boundary/conflict candidate | 10/12 | 12/12 | 12/12 |

The candidate did not improve the raw count in this set. Both arms missed EXP-EB-005: the model included the terminal exclamation mark in “Poetry Under Glass!”. The gold label excludes it under the exploratory convention, which the contract does not specify; report this case separately.

The candidate also missed EXP-UC-003. It returned “The Film Poster Workshop” instead of “Film Poster Workshop”; its date and null venue were correct. Thus the candidate handled the unresolved venue as null but the event-field mismatch made the record incorrect. The baseline got this record correct.

By category, both arms scored 5/5 on event-title-versus-organizer cases and 5/5 on unresolved-date conflicts. Both scored 0/1 on the punctuation-review case. The baseline scored 1/1 on the unresolved-venue case; the candidate scored 0/1.

All 24 responses were valid JSON and schema-valid. The run took 8.50 seconds, used Qwen/Qwen2.5-14B-Instruct revision `cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8`, and reported no OOM events. Input, label, and prompt hashes in `exploratory_v2_comparison.json` match the local project artifacts.

This 12-case, post-hoc comparison is descriptive only. The conflict subset contains five date cases and one venue case, and the notices explicitly signal the absence of priority. Do not use these results to revise or rescore the primary study.
