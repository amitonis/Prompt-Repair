# PromptRepair final report: D6

- Model: Qwen/Qwen2.5-14B-Instruct
- Test notices: 40 across 14 families
- Final evaluation time: 23.21 seconds
- Scope: Descriptive single-setting results; only D6 survived screening.

## Main finding

Targeted repair and full rewrite both scored 35/40 (87.5%); their observed paired difference was +0.0%. In this retained setting, targeted repair matched rewriting but did not outperform it. Only one setting survived screening, so this is descriptive evidence for this dataset, not a general result.
The output-format-only random-section arm also scored 35/40 (87.5%); the constraints-plus-output-format baseline scored 35/40 (87.5%). These matched scores make output-format instructions a relevant factor to investigate, but do not isolate a causal effect.

## Final test accuracy

| Arm | Strict accuracy | JSON valid | Schema valid |
| --- | ---: | ---: | ---: |
| defective | 0/40 (0.0%) | 40/40 | 0/40 |
| rewrite | 35/40 (87.5%) | 40/40 | 40/40 |
| span | 35/40 (87.5%) | 40/40 | 40/40 |
| L-Rule | 35/40 (87.5%) | 40/40 | 40/40 |
| L-LLM | 35/40 (87.5%) | 40/40 | 40/40 |
| L-Behav | 35/40 (87.5%) | 40/40 | 40/40 |
| oracle-section | 35/40 (87.5%) | 40/40 | 40/40 |
| oracle | 35/40 (87.5%) | 40/40 | 40/40 |
| random_instruction | 0/40 (0.0%) | 40/40 | 0/40 |
| random_context | 11/40 (27.5%) | 40/40 | 11/40 |
| random_constraints | 0/40 (0.0%) | 40/40 | 0/40 |
| random_output_format | 35/40 (87.5%) | 40/40 | 40/40 |
| original | 0/40 (0.0%) | 2/40 | 2/40 |
| restricted_baseline | 35/40 (87.5%) | 40/40 | 40/40 |

## Paired comparisons (descriptive for this single retained setting)

- P1, L-LLM minus rewrite: +0.0%; 95% family-bootstrap CI [+0.0%, +0.0%]; bootstrap p=1.0000; exact family sign-flip p=1.0000.
- P2, oracle-section minus random-section mean: +58.8%; 95% family-bootstrap CI [+46.5%, +69.9%]; bootstrap p<0.0001 (0/10000 draws); exact family sign-flip p=0.0002.

## Sensitivity and limits

Oracle accuracy excluding TEST-001–TEST-004: 34/36 (94.4%).
Preregistered confirmatory across-setting tests and Holm correction are not run: one setting survived defect screening. Within-setting intervals and p-values are descriptive.
Original-prompt development gate: 20/20 strict failures in 3.58 seconds; the arm qualifies for inclusion. All 20 failures were malformed JSON because outputs were wrapped in Markdown code fences. Original-prompt final-test result: 0/40 (0.0%); issue counts: {'MALFORMED_JSON': 38, 'NULL_POLICY_VIOLATION': 2}.
Restricted-baseline development result: 18/20 (90.0%); final-test result: 35/40 (87.5%); 40/40 valid JSON and 40/40 valid schema. The run occurred after other final-test results were observed; no prompt changes were made.
## Failure analysis

See [ERROR_ANALYSIS.md](ERROR_ANALYSIS.md) for category-level accuracy, the five remaining error cases, and the possible punctuation-boundary ambiguity in three frozen labels.

Exploratory L-Probe was not evaluated.

## Runtime deviation

- Transformers version: planned 5.20.2; observed 5.21.0.
