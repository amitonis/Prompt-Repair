# Frozen primary-test field diagnostics

Offline descriptive reanalysis of saved primary outputs. No labels, prompts, or primary scores were changed.

Exact field matches follow the existing evaluator and are independent of the other fields and schema validity. JSON validity, schema validity, exact-record correctness, and field exactness are reported separately. The conditional count uses schema-valid records only.

| Arm | Record correct | JSON valid | Schema valid | Event exact | Date exact | Venue exact |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| defective | 0/40 | 40/40 | 0/40 | 37/40 | 38/40 | 0/40 |
| rewrite | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| span | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| L-Rule | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| L-LLM | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| L-Behav | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| oracle-section | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| oracle | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| random_instruction | 0/40 | 40/40 | 0/40 | 37/40 | 38/40 | 0/40 |
| random_context | 11/40 | 40/40 | 11/40 | 37/40 | 38/40 | 11/40 |
| random_constraints | 0/40 | 40/40 | 0/40 | 37/40 | 38/40 | 0/40 |
| random_output_format | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |
| original | 0/40 | 2/40 | 2/40 | 2/40 | 0/40 | 0/40 |
| restricted_baseline | 35/40 | 40/40 | 40/40 | 37/40 | 38/40 | 40/40 |

Shared incorrect IDs for rewrite, oracle, and restricted baseline: TEST-001, TEST-003, TEST-004, TEST-037, TEST-038.

## Error groups

### defective

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026"}` |
| TEST-002 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Paper Planes Workshop", "date": "7 November 2026", "venue": "Room 104 of the Science Block"}` | `{"event": "Paper Planes Workshop", "date": "7 November 2026"}` |
| TEST-003 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026"}` |
| TEST-004 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026"}` |
| TEST-005 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Silent Reading Marathon", "date": "20 November 2026", "venue": "Library Basement"}` | `{"event": "Silent Reading Marathon", "date": "20 November 2026"}` |
| TEST-006 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Telescope Basics", "date": "23 November 2026", "venue": "Physics Lab 3"}` | `{"event": "Telescope Basics", "date": "23 November 2026"}` |
| TEST-007 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Decadence", "date": "26 November 2026", "venue": "Home Science Kitchen"}` | `{"event": "Decadence", "date": "26 November 2026"}` |
| TEST-008 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Improv Jam", "date": "27 November 2026", "venue": "Black Box Studio"}` | `{"event": "Improv Jam", "date": "27 November 2026"}` |
| TEST-009 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Cosplay 101", "date": "28 November 2026", "venue": null}` | `{"event": "Cosplay 101", "date": "28 November 2026"}` |
| TEST-010 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Retro Arcade Night", "date": "29 November 2026", "venue": null}` | `{"event": "Retro Arcade Night", "date": "29 November 2026"}` |
| TEST-011 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Trail Talk", "date": "30 November 2026", "venue": null}` | `{"event": "Trail Talk", "date": "30 November 2026"}` |
| TEST-012 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Junior Moot Court", "date": "1 December 2026", "venue": null}` | `{"event": "Junior Moot Court", "date": "1 December 2026"}` |
| TEST-013 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Slime-Making Saturday", "date": "2 December 2026", "venue": null}` | `{"event": "Slime-Making Saturday", "date": "2 December 2026"}` |
| TEST-014 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "The Green Walk", "date": "3 December 2026", "venue": null}` | `{"event": "The Green Walk", "date": "3 December 2026"}` |
| TEST-015 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Winter Strings", "date": "4 December 2026", "venue": null}` | `{"event": "Winter Strings", "date": "4 December 2026"}` |
| TEST-016 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Open Mic Night", "date": "5 December 2026", "venue": null}` | `{"event": "Open Mic Night", "date": "5 December 2026"}` |
| TEST-017 | date_absent | venue | SCHEMA_KEYS | `{"event": "Fresher Art Jam", "date": null, "venue": "Courtyard Gallery"}` | `{"event": "Fresher Art Jam", "date": null}` |
| TEST-018 | date_absent | venue | SCHEMA_KEYS | `{"event": "Chai and Chapters", "date": null, "venue": "Cosy Corner"}` | `{"event": "Chai and Chapters", "date": null}` |
| TEST-019 | date_absent | venue | SCHEMA_KEYS | `{"event": "Vintage Car Showcase", "date": null, "venue": "North Parking Lot"}` | `{"event": "Vintage Car Showcase", "date": null}` |
| TEST-020 | date_absent | venue | SCHEMA_KEYS | `{"event": "Founders' Fireside", "date": null, "venue": "Board Room"}` | `{"event": "Founders' Fireside", "date": null}` |
| TEST-021 | date_absent | venue | SCHEMA_KEYS | `{"event": "Line-Follower Challenge", "date": null, "venue": "Makerspace"}` | `{"event": "Line-Follower Challenge", "date": null}` |
| TEST-022 | date_absent | venue | SCHEMA_KEYS | `{"event": "Golden Hour Walk", "date": null, "venue": "Campus Gardens"}` | `{"event": "Golden Hour Walk", "date": null}` |
| TEST-023 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Fondue Night", "date": "4 December 2026", "venue": "Training Kitchen"}` | `{"event": "Fondue Night", "date": "4 December 2026"}` |
| TEST-024 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "A Capella Auditions", "date": "6 December 2026", "venue": "Choir Room"}` | `{"event": "A Capella Auditions", "date": "6 December 2026"}` |
| TEST-025 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Laser Tag Arena", "date": "8 December 2026", "venue": "Indoor Stadium"}` | `{"event": "Laser Tag Arena", "date": "8 December 2026"}` |
| TEST-026 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Hack the Campus", "date": "9 December 2026", "venue": "Computer Lab 1"}` | `{"event": "Hack the Campus", "date": "9 December 2026"}` |
| TEST-027 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026", "venue": "Structures Lab"}` | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026"}` |
| TEST-028 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Zine-Making Day", "date": "11 December 2026", "venue": "Print Studio"}` | `{"event": "Zine-Making Day", "date": "11 December 2026"}` |
| TEST-029 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Heritage Food Walk", "date": "15 November 2026", "venue": "Heritage Kitchen"}` | `{"event": "Heritage Food Walk", "date": "15 November 2026"}` |
| TEST-030 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Odissi Recital", "date": "19 November 2026", "venue": "Dance Studio 2"}` | `{"event": "Odissi Recital", "date": "19 November 2026"}` |
| TEST-031 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Rubik's Rumble", "date": "20 November 2026", "venue": "Seminar Room 7"}` | `{"event": "Rubik's Rumble", "date": "20 November 2026"}` |
| TEST-032 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026", "venue": "Dance Studio 1"}` | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026"}` |
| TEST-033 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Alumni Mixer", "date": "25 November 2026", "venue": "West Court"}` | `{"event": "Alumni Mixer", "date": "25 November 2026"}` |
| TEST-034 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026", "venue": "Lecture Theatre 4"}` | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026"}` |
| TEST-035 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026", "venue": null}` | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026"}` |
| TEST-036 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Sudoku Sprint", "date": "25 November 2026", "venue": null}` | `{"event": "Sudoku Sprint", "date": "25 November 2026"}` |
| TEST-037 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026"}` |
| TEST-038 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026"}` |
| TEST-039 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Winter Charity Auction", "date": null, "venue": null}` | `{"event": "Winter Charity Auction", "date": null}` |
| TEST-040 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Poetry Slam Finals", "date": null, "venue": null}` | `{"event": "Poetry Slam Finals", "date": null}` |

### rewrite

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### span

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### L-Rule

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### L-LLM

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### L-Behav

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### oracle-section

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### oracle

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### random_instruction

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026"}` |
| TEST-002 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Paper Planes Workshop", "date": "7 November 2026", "venue": "Room 104 of the Science Block"}` | `{"event": "Paper Planes Workshop", "date": "7 November 2026"}` |
| TEST-003 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026"}` |
| TEST-004 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026"}` |
| TEST-005 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Silent Reading Marathon", "date": "20 November 2026", "venue": "Library Basement"}` | `{"event": "Silent Reading Marathon", "date": "20 November 2026"}` |
| TEST-006 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Telescope Basics", "date": "23 November 2026", "venue": "Physics Lab 3"}` | `{"event": "Telescope Basics", "date": "23 November 2026"}` |
| TEST-007 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Decadence", "date": "26 November 2026", "venue": "Home Science Kitchen"}` | `{"event": "Decadence", "date": "26 November 2026"}` |
| TEST-008 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Improv Jam", "date": "27 November 2026", "venue": "Black Box Studio"}` | `{"event": "Improv Jam", "date": "27 November 2026"}` |
| TEST-009 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Cosplay 101", "date": "28 November 2026", "venue": null}` | `{"event": "Cosplay 101", "date": "28 November 2026"}` |
| TEST-010 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Retro Arcade Night", "date": "29 November 2026", "venue": null}` | `{"event": "Retro Arcade Night", "date": "29 November 2026"}` |
| TEST-011 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Trail Talk", "date": "30 November 2026", "venue": null}` | `{"event": "Trail Talk", "date": "30 November 2026"}` |
| TEST-012 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Junior Moot Court", "date": "1 December 2026", "venue": null}` | `{"event": "Junior Moot Court", "date": "1 December 2026"}` |
| TEST-013 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Slime-Making Saturday", "date": "2 December 2026", "venue": null}` | `{"event": "Slime-Making Saturday", "date": "2 December 2026"}` |
| TEST-014 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "The Green Walk", "date": "3 December 2026", "venue": null}` | `{"event": "The Green Walk", "date": "3 December 2026"}` |
| TEST-015 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Winter Strings", "date": "4 December 2026", "venue": null}` | `{"event": "Winter Strings", "date": "4 December 2026"}` |
| TEST-016 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Open Mic Night", "date": "5 December 2026", "venue": null}` | `{"event": "Open Mic Night", "date": "5 December 2026"}` |
| TEST-017 | date_absent | venue | SCHEMA_KEYS | `{"event": "Fresher Art Jam", "date": null, "venue": "Courtyard Gallery"}` | `{"event": "Fresher Art Jam", "date": null}` |
| TEST-018 | date_absent | venue | SCHEMA_KEYS | `{"event": "Chai and Chapters", "date": null, "venue": "Cosy Corner"}` | `{"event": "Chai and Chapters", "date": null}` |
| TEST-019 | date_absent | venue | SCHEMA_KEYS | `{"event": "Vintage Car Showcase", "date": null, "venue": "North Parking Lot"}` | `{"event": "Vintage Car Showcase", "date": null}` |
| TEST-020 | date_absent | venue | SCHEMA_KEYS | `{"event": "Founders' Fireside", "date": null, "venue": "Board Room"}` | `{"event": "Founders' Fireside", "date": null}` |
| TEST-021 | date_absent | venue | SCHEMA_KEYS | `{"event": "Line-Follower Challenge", "date": null, "venue": "Makerspace"}` | `{"event": "Line-Follower Challenge", "date": null}` |
| TEST-022 | date_absent | venue | SCHEMA_KEYS | `{"event": "Golden Hour Walk", "date": null, "venue": "Campus Gardens"}` | `{"event": "Golden Hour Walk", "date": null}` |
| TEST-023 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Fondue Night", "date": "4 December 2026", "venue": "Training Kitchen"}` | `{"event": "Fondue Night", "date": "4 December 2026"}` |
| TEST-024 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "A Capella Auditions", "date": "6 December 2026", "venue": "Choir Room"}` | `{"event": "A Capella Auditions", "date": "6 December 2026"}` |
| TEST-025 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Laser Tag Arena", "date": "8 December 2026", "venue": "Indoor Stadium"}` | `{"event": "Laser Tag Arena", "date": "8 December 2026"}` |
| TEST-026 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Hack the Campus", "date": "9 December 2026", "venue": "Computer Lab 1"}` | `{"event": "Hack the Campus", "date": "9 December 2026"}` |
| TEST-027 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026", "venue": "Structures Lab"}` | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026"}` |
| TEST-028 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Zine-Making Day", "date": "11 December 2026", "venue": "Print Studio"}` | `{"event": "Zine-Making Day", "date": "11 December 2026"}` |
| TEST-029 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Heritage Food Walk", "date": "15 November 2026", "venue": "Heritage Kitchen"}` | `{"event": "Heritage Food Walk", "date": "15 November 2026"}` |
| TEST-030 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Odissi Recital", "date": "19 November 2026", "venue": "Dance Studio 2"}` | `{"event": "Odissi Recital", "date": "19 November 2026"}` |
| TEST-031 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Rubik's Rumble", "date": "20 November 2026", "venue": "Seminar Room 7"}` | `{"event": "Rubik's Rumble", "date": "20 November 2026"}` |
| TEST-032 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026", "venue": "Dance Studio 1"}` | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026"}` |
| TEST-033 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Alumni Mixer", "date": "25 November 2026", "venue": "West Court"}` | `{"event": "Alumni Mixer", "date": "25 November 2026"}` |
| TEST-034 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026", "venue": "Lecture Theatre 4"}` | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026"}` |
| TEST-035 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026", "venue": null}` | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026"}` |
| TEST-036 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Sudoku Sprint", "date": "25 November 2026", "venue": null}` | `{"event": "Sudoku Sprint", "date": "25 November 2026"}` |
| TEST-037 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026"}` |
| TEST-038 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026"}` |
| TEST-039 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Winter Charity Auction", "date": null, "venue": null}` | `{"event": "Winter Charity Auction", "date": null}` |
| TEST-040 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Poetry Slam Finals", "date": null, "venue": null}` | `{"event": "Poetry Slam Finals", "date": null}` |

### random_context

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026"}` |
| TEST-002 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Paper Planes Workshop", "date": "7 November 2026", "venue": "Room 104 of the Science Block"}` | `{"event": "Paper Planes Workshop", "date": "7 November 2026"}` |
| TEST-003 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026"}` |
| TEST-004 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026"}` |
| TEST-005 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Silent Reading Marathon", "date": "20 November 2026", "venue": "Library Basement"}` | `{"event": "Silent Reading Marathon", "date": "20 November 2026"}` |
| TEST-006 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Telescope Basics", "date": "23 November 2026", "venue": "Physics Lab 3"}` | `{"event": "Telescope Basics", "date": "23 November 2026"}` |
| TEST-007 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Decadence", "date": "26 November 2026", "venue": "Home Science Kitchen"}` | `{"event": "Decadence", "date": "26 November 2026"}` |
| TEST-008 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Improv Jam", "date": "27 November 2026", "venue": "Black Box Studio"}` | `{"event": "Improv Jam", "date": "27 November 2026"}` |
| TEST-017 | date_absent | venue | SCHEMA_KEYS | `{"event": "Fresher Art Jam", "date": null, "venue": "Courtyard Gallery"}` | `{"event": "Fresher Art Jam", "date": null}` |
| TEST-018 | date_absent | venue | SCHEMA_KEYS | `{"event": "Chai and Chapters", "date": null, "venue": "Cosy Corner"}` | `{"event": "Chai and Chapters", "date": null}` |
| TEST-019 | date_absent | venue | SCHEMA_KEYS | `{"event": "Vintage Car Showcase", "date": null, "venue": "North Parking Lot"}` | `{"event": "Vintage Car Showcase", "date": null}` |
| TEST-020 | date_absent | venue | SCHEMA_KEYS | `{"event": "Founders' Fireside", "date": null, "venue": "Board Room"}` | `{"event": "Founders' Fireside", "date": null}` |
| TEST-021 | date_absent | venue | SCHEMA_KEYS | `{"event": "Line-Follower Challenge", "date": null, "venue": "Makerspace"}` | `{"event": "Line-Follower Challenge", "date": null}` |
| TEST-022 | date_absent | venue | SCHEMA_KEYS | `{"event": "Golden Hour Walk", "date": null, "venue": "Campus Gardens"}` | `{"event": "Golden Hour Walk", "date": null}` |
| TEST-023 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Fondue Night", "date": "4 December 2026", "venue": "Training Kitchen"}` | `{"event": "Fondue Night", "date": "4 December 2026"}` |
| TEST-024 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "A Capella Auditions", "date": "6 December 2026", "venue": "Choir Room"}` | `{"event": "A Capella Auditions", "date": "6 December 2026"}` |
| TEST-025 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Laser Tag Arena", "date": "8 December 2026", "venue": "Indoor Stadium"}` | `{"event": "Laser Tag Arena", "date": "8 December 2026"}` |
| TEST-026 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Hack the Campus", "date": "9 December 2026", "venue": "Computer Lab 1"}` | `{"event": "Hack the Campus", "date": "9 December 2026"}` |
| TEST-027 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026", "venue": "Structures Lab"}` | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026"}` |
| TEST-028 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Zine-Making Day", "date": "11 December 2026", "venue": "Print Studio"}` | `{"event": "Zine-Making Day", "date": "11 December 2026"}` |
| TEST-029 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Heritage Food Walk", "date": "15 November 2026", "venue": "Heritage Kitchen"}` | `{"event": "Heritage Food Walk", "date": "15 November 2026"}` |
| TEST-030 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Odissi Recital", "date": "19 November 2026", "venue": "Dance Studio 2"}` | `{"event": "Odissi Recital", "date": "19 November 2026"}` |
| TEST-031 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Rubik's Rumble", "date": "20 November 2026", "venue": "Seminar Room 7"}` | `{"event": "Rubik's Rumble", "date": "20 November 2026"}` |
| TEST-032 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026", "venue": "Dance Studio 1"}` | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026"}` |
| TEST-033 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Alumni Mixer", "date": "25 November 2026", "venue": "West Court"}` | `{"event": "Alumni Mixer", "date": "25 November 2026"}` |
| TEST-034 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026", "venue": "Lecture Theatre 4"}` | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026"}` |
| TEST-036 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Sudoku Sprint", "date": "25 November 2026", "venue": null}` | `{"event": "Sudoku Sprint", "date": "25 November 2026"}` |
| TEST-037 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026"}` |
| TEST-038 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026"}` |

### random_constraints

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026"}` |
| TEST-002 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Paper Planes Workshop", "date": "7 November 2026", "venue": "Room 104 of the Science Block"}` | `{"event": "Paper Planes Workshop", "date": "7 November 2026"}` |
| TEST-003 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026"}` |
| TEST-004 | complete_unambiguous | event, venue | SCHEMA_KEYS, EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026"}` |
| TEST-005 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Silent Reading Marathon", "date": "20 November 2026", "venue": "Library Basement"}` | `{"event": "Silent Reading Marathon", "date": "20 November 2026"}` |
| TEST-006 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Telescope Basics", "date": "23 November 2026", "venue": "Physics Lab 3"}` | `{"event": "Telescope Basics", "date": "23 November 2026"}` |
| TEST-007 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Decadence", "date": "26 November 2026", "venue": "Home Science Kitchen"}` | `{"event": "Decadence", "date": "26 November 2026"}` |
| TEST-008 | complete_unambiguous | venue | SCHEMA_KEYS | `{"event": "Improv Jam", "date": "27 November 2026", "venue": "Black Box Studio"}` | `{"event": "Improv Jam", "date": "27 November 2026"}` |
| TEST-009 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Cosplay 101", "date": "28 November 2026", "venue": null}` | `{"event": "Cosplay 101", "date": "28 November 2026"}` |
| TEST-010 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Retro Arcade Night", "date": "29 November 2026", "venue": null}` | `{"event": "Retro Arcade Night", "date": "29 November 2026"}` |
| TEST-011 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Trail Talk", "date": "30 November 2026", "venue": null}` | `{"event": "Trail Talk", "date": "30 November 2026"}` |
| TEST-012 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Junior Moot Court", "date": "1 December 2026", "venue": null}` | `{"event": "Junior Moot Court", "date": "1 December 2026"}` |
| TEST-013 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Slime-Making Saturday", "date": "2 December 2026", "venue": null}` | `{"event": "Slime-Making Saturday", "date": "2 December 2026"}` |
| TEST-014 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "The Green Walk", "date": "3 December 2026", "venue": null}` | `{"event": "The Green Walk", "date": "3 December 2026"}` |
| TEST-015 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Winter Strings", "date": "4 December 2026", "venue": null}` | `{"event": "Winter Strings", "date": "4 December 2026"}` |
| TEST-016 | venue_absent_or_pending | venue | SCHEMA_KEYS | `{"event": "Open Mic Night", "date": "5 December 2026", "venue": null}` | `{"event": "Open Mic Night", "date": "5 December 2026"}` |
| TEST-017 | date_absent | venue | SCHEMA_KEYS | `{"event": "Fresher Art Jam", "date": null, "venue": "Courtyard Gallery"}` | `{"event": "Fresher Art Jam", "date": null}` |
| TEST-018 | date_absent | venue | SCHEMA_KEYS | `{"event": "Chai and Chapters", "date": null, "venue": "Cosy Corner"}` | `{"event": "Chai and Chapters", "date": null}` |
| TEST-019 | date_absent | venue | SCHEMA_KEYS | `{"event": "Vintage Car Showcase", "date": null, "venue": "North Parking Lot"}` | `{"event": "Vintage Car Showcase", "date": null}` |
| TEST-020 | date_absent | venue | SCHEMA_KEYS | `{"event": "Founders' Fireside", "date": null, "venue": "Board Room"}` | `{"event": "Founders' Fireside", "date": null}` |
| TEST-021 | date_absent | venue | SCHEMA_KEYS | `{"event": "Line-Follower Challenge", "date": null, "venue": "Makerspace"}` | `{"event": "Line-Follower Challenge", "date": null}` |
| TEST-022 | date_absent | venue | SCHEMA_KEYS | `{"event": "Golden Hour Walk", "date": null, "venue": "Campus Gardens"}` | `{"event": "Golden Hour Walk", "date": null}` |
| TEST-023 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Fondue Night", "date": "4 December 2026", "venue": "Training Kitchen"}` | `{"event": "Fondue Night", "date": "4 December 2026"}` |
| TEST-024 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "A Capella Auditions", "date": "6 December 2026", "venue": "Choir Room"}` | `{"event": "A Capella Auditions", "date": "6 December 2026"}` |
| TEST-025 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Laser Tag Arena", "date": "8 December 2026", "venue": "Indoor Stadium"}` | `{"event": "Laser Tag Arena", "date": "8 December 2026"}` |
| TEST-026 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Hack the Campus", "date": "9 December 2026", "venue": "Computer Lab 1"}` | `{"event": "Hack the Campus", "date": "9 December 2026"}` |
| TEST-027 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026", "venue": "Structures Lab"}` | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026"}` |
| TEST-028 | deadline_distractor | venue | SCHEMA_KEYS | `{"event": "Zine-Making Day", "date": "11 December 2026", "venue": "Print Studio"}` | `{"event": "Zine-Making Day", "date": "11 December 2026"}` |
| TEST-029 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Heritage Food Walk", "date": "15 November 2026", "venue": "Heritage Kitchen"}` | `{"event": "Heritage Food Walk", "date": "15 November 2026"}` |
| TEST-030 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Odissi Recital", "date": "19 November 2026", "venue": "Dance Studio 2"}` | `{"event": "Odissi Recital", "date": "19 November 2026"}` |
| TEST-031 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Rubik's Rumble", "date": "20 November 2026", "venue": "Seminar Room 7"}` | `{"event": "Rubik's Rumble", "date": "20 November 2026"}` |
| TEST-032 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026", "venue": "Dance Studio 1"}` | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026"}` |
| TEST-033 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Alumni Mixer", "date": "25 November 2026", "venue": "West Court"}` | `{"event": "Alumni Mixer", "date": "25 November 2026"}` |
| TEST-034 | explicit_correction | venue | SCHEMA_KEYS | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026", "venue": "Lecture Theatre 4"}` | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026"}` |
| TEST-035 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026", "venue": null}` | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026"}` |
| TEST-036 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Sudoku Sprint", "date": "25 November 2026", "venue": null}` | `{"event": "Sudoku Sprint", "date": "25 November 2026"}` |
| TEST-037 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026"}` |
| TEST-038 | unresolved_conflict | date, venue | SCHEMA_KEYS, NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026"}` |
| TEST-039 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Winter Charity Auction", "date": null, "venue": null}` | `{"event": "Winter Charity Auction", "date": null}` |
| TEST-040 | unresolved_conflict | venue | SCHEMA_KEYS | `{"event": "Poetry Slam Finals", "date": null, "venue": null}` | `{"event": "Poetry Slam Finals", "date": null}` |

### random_output_format

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"}` |

### original

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `null` |
| TEST-002 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Paper Planes Workshop", "date": "7 November 2026", "venue": "Room 104 of the Science Block"}` | `null` |
| TEST-003 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `null` |
| TEST-004 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `null` |
| TEST-005 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Silent Reading Marathon", "date": "20 November 2026", "venue": "Library Basement"}` | `null` |
| TEST-006 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Telescope Basics", "date": "23 November 2026", "venue": "Physics Lab 3"}` | `null` |
| TEST-007 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Decadence", "date": "26 November 2026", "venue": "Home Science Kitchen"}` | `null` |
| TEST-008 | complete_unambiguous | event, date, venue | MALFORMED_JSON | `{"event": "Improv Jam", "date": "27 November 2026", "venue": "Black Box Studio"}` | `null` |
| TEST-009 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Cosplay 101", "date": "28 November 2026", "venue": null}` | `null` |
| TEST-010 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Retro Arcade Night", "date": "29 November 2026", "venue": null}` | `null` |
| TEST-011 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Trail Talk", "date": "30 November 2026", "venue": null}` | `null` |
| TEST-012 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Junior Moot Court", "date": "1 December 2026", "venue": null}` | `null` |
| TEST-013 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Slime-Making Saturday", "date": "2 December 2026", "venue": null}` | `null` |
| TEST-014 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "The Green Walk", "date": "3 December 2026", "venue": null}` | `null` |
| TEST-015 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Winter Strings", "date": "4 December 2026", "venue": null}` | `null` |
| TEST-016 | venue_absent_or_pending | event, date, venue | MALFORMED_JSON | `{"event": "Open Mic Night", "date": "5 December 2026", "venue": null}` | `null` |
| TEST-017 | date_absent | event, date, venue | MALFORMED_JSON | `{"event": "Fresher Art Jam", "date": null, "venue": "Courtyard Gallery"}` | `null` |
| TEST-018 | date_absent | event, date, venue | MALFORMED_JSON | `{"event": "Chai and Chapters", "date": null, "venue": "Cosy Corner"}` | `null` |
| TEST-019 | date_absent | event, date, venue | MALFORMED_JSON | `{"event": "Vintage Car Showcase", "date": null, "venue": "North Parking Lot"}` | `null` |
| TEST-020 | date_absent | event, date, venue | MALFORMED_JSON | `{"event": "Founders' Fireside", "date": null, "venue": "Board Room"}` | `null` |
| TEST-021 | date_absent | event, date, venue | MALFORMED_JSON | `{"event": "Line-Follower Challenge", "date": null, "venue": "Makerspace"}` | `null` |
| TEST-022 | date_absent | event, date, venue | MALFORMED_JSON | `{"event": "Golden Hour Walk", "date": null, "venue": "Campus Gardens"}` | `null` |
| TEST-023 | deadline_distractor | event, date, venue | MALFORMED_JSON | `{"event": "Fondue Night", "date": "4 December 2026", "venue": "Training Kitchen"}` | `null` |
| TEST-024 | deadline_distractor | event, date, venue | MALFORMED_JSON | `{"event": "A Capella Auditions", "date": "6 December 2026", "venue": "Choir Room"}` | `null` |
| TEST-025 | deadline_distractor | event, date, venue | MALFORMED_JSON | `{"event": "Laser Tag Arena", "date": "8 December 2026", "venue": "Indoor Stadium"}` | `null` |
| TEST-026 | deadline_distractor | event, date, venue | MALFORMED_JSON | `{"event": "Hack the Campus", "date": "9 December 2026", "venue": "Computer Lab 1"}` | `null` |
| TEST-027 | deadline_distractor | event, date, venue | MALFORMED_JSON | `{"event": "Bridge Building Bootcamp", "date": "10 December 2026", "venue": "Structures Lab"}` | `null` |
| TEST-028 | deadline_distractor | event, date, venue | MALFORMED_JSON | `{"event": "Zine-Making Day", "date": "11 December 2026", "venue": "Print Studio"}` | `null` |
| TEST-029 | explicit_correction | event, date, venue | MALFORMED_JSON | `{"event": "Heritage Food Walk", "date": "15 November 2026", "venue": "Heritage Kitchen"}` | `null` |
| TEST-030 | explicit_correction | event, date, venue | MALFORMED_JSON | `{"event": "Odissi Recital", "date": "19 November 2026", "venue": "Dance Studio 2"}` | `null` |
| TEST-031 | explicit_correction | event, date, venue | MALFORMED_JSON | `{"event": "Rubik's Rumble", "date": "20 November 2026", "venue": "Seminar Room 7"}` | `null` |
| TEST-032 | explicit_correction | event, date, venue | MALFORMED_JSON | `{"event": "Bharatanatyam Workshop", "date": "21 November 2026", "venue": "Dance Studio 1"}` | `null` |
| TEST-033 | explicit_correction | event, date, venue | MALFORMED_JSON | `{"event": "Alumni Mixer", "date": "25 November 2026", "venue": "West Court"}` | `null` |
| TEST-034 | explicit_correction | event, date, venue | MALFORMED_JSON | `{"event": "Astronomy Olympiad Briefing", "date": "26 November 2026", "venue": "Lecture Theatre 4"}` | `null` |
| TEST-035 | unresolved_conflict | event, date, venue | MALFORMED_JSON | `{"event": "Pumpkin Carving Contest", "date": "24 November 2026", "venue": null}` | `null` |
| TEST-036 | unresolved_conflict | event, date, venue | MALFORMED_JSON | `{"event": "Sudoku Sprint", "date": "25 November 2026", "venue": null}` | `null` |
| TEST-037 | unresolved_conflict | event, date, venue | MALFORMED_JSON | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `null` |
| TEST-038 | unresolved_conflict | event, date, venue | MALFORMED_JSON | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `null` |
| TEST-039 | unresolved_conflict | date, venue | NULL_POLICY_VIOLATION | `{"event": "Winter Charity Auction", "date": null, "venue": null}` | `{"event": "Winter Charity Auction", "date": "30 November 2026 / 1 December 2026", "venue": "Main Hall / West Court"}` |
| TEST-040 | unresolved_conflict | date, venue | NULL_POLICY_VIOLATION | `{"event": "Poetry Slam Finals", "date": null, "venue": null}` | `{"event": "Poetry Slam Finals", "date": "2 December 2026 or 3 December 2026", "venue": "Amphitheatre Steps or Seminar Room 2"}` |

### restricted_baseline

| ID | Category | Wrong fields | Issue codes | Expected | Observed |
| --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Trivia Royale", "date": "4 November 2026", "venue": "Seminar Room 5"}` | `{"event": "Trivia Royale! The Quiz Society", "date": "4 November 2026", "venue": "Seminar Room 5"}` |
| TEST-003 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Night Sky Watch", "date": "10 November 2026", "venue": "Observatory Deck"}` | `{"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"}` |
| TEST-004 | complete_unambiguous | event | EVENT_MISMATCH | `{"event": "Spelling Bee Showdown", "date": "13 November 2026", "venue": "East Wing Classroom"}` | `{"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"}` |
| TEST-037 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Ethics Slam", "date": null, "venue": "Seminar Room 9"}` | `{"event": "Ethics Slam", "date": "2026-11-27", "venue": "Seminar Room 9"}` |
| TEST-038 | unresolved_conflict | date | NULL_POLICY_VIOLATION | `{"event": "Kite Festival", "date": null, "venue": "Sports Field"}` | `{"event": "Kite Festival", "date": "2026-11-29", "venue": "Sports Field"}` |

## Reading the field counts

Field totals are diagnostic views of the same scorer, not additional independent outcomes. A record can have multiple correct fields and still fail exact-record accuracy or schema validation. The primary study remains scored exactly as preregistered.
