# D6 final-test error analysis

Generated from the frozen test labels and saved final-test outputs. This analysis does not change any labels or strict scores.

## Accuracy by category

| Category | Rewrite | Oracle | Restricted baseline |
| --- | ---: | ---: | ---: |
| complete_unambiguous | 5/8 | 5/8 | 5/8 |
| venue_absent_or_pending | 8/8 | 8/8 | 8/8 |
| date_absent | 6/6 | 6/6 | 6/6 |
| deadline_distractor | 6/6 | 6/6 | 6/6 |
| explicit_correction | 6/6 | 6/6 | 6/6 |
| unresolved_conflict | 4/6 | 4/6 | 4/6 |

All three listed arms scored 35/40 (87.5%) and had valid JSON and schema on all 40 notices. They scored 26/26 on venue-absent/pending, date-absent, deadline-distractor, and explicit-correction cases. Their remaining errors were concentrated in complete event names and unresolved date conflicts.

## Incorrect cases

| ID | Category | Field / issue | Expected | Rewrite output | Oracle output | Restricted-baseline output |
| --- | --- | --- | --- | --- | --- | --- |
| TEST-001 | complete_unambiguous | event (EVENT_MISMATCH) | {"event": "Trivia Royale"} | {"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"} | {"event": "Trivia Royale!", "date": "4 November 2026", "venue": "Seminar Room 5"} | {"event": "Trivia Royale! The Quiz Society", "date": "4 November 2026", "venue": "Seminar Room 5"} |
| TEST-003 | complete_unambiguous | event (EVENT_MISMATCH) | {"event": "Night Sky Watch"} | {"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"} | {"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"} | {"event": "Night Sky Watch!", "date": "10 November 2026", "venue": "Observatory Deck"} |
| TEST-004 | complete_unambiguous | event (EVENT_MISMATCH) | {"event": "Spelling Bee Showdown"} | {"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"} | {"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"} | {"event": "Spelling Bee Showdown!", "date": "13 November 2026", "venue": "East Wing Classroom"} |
| TEST-037 | unresolved_conflict | date (NULL_POLICY_VIOLATION) | {"date": null} | {"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"} | {"event": "Ethics Slam", "date": "27 November 2026", "venue": "Seminar Room 9"} | {"event": "Ethics Slam", "date": "2026-11-27", "venue": "Seminar Room 9"} |
| TEST-038 | unresolved_conflict | date (NULL_POLICY_VIOLATION) | {"date": null} | {"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"} | {"event": "Kite Festival", "date": "29 November 2026", "venue": "Sports Field"} | {"event": "Kite Festival", "date": "2026-11-29", "venue": "Sports Field"} |

## Development-set signal and protocol boundary

The restricted-baseline development result was 10/10 on feedback and 8/10 on selection. Both development errors were selection cases:
- `SEL-005` (selection): expected event "Kiln and Clay"; observed "Kiln and Clay by the Arts Society".
- `SEL-006` (selection): expected event "Watercolour Mornings"; observed "Watercolour Mornings by the Fine Arts Group".
The feedback subset had no errors to provide as editor examples. Under the frozen procedure, the selection subset evaluates candidate acceptance; it must not be reused to invent or tune the primary prompt. A follow-up that targets event-name boundaries should use a separately collected and reviewed exploratory set, with results kept distinct from the preregistered study.

The rewrite, oracle, and restricted-baseline arms failed the same five IDs: TEST-001, TEST-003, TEST-004, TEST-037, TEST-038.
Three complete-event cases (TEST-001, TEST-003, TEST-004) are strict event-name mismatches involving terminal punctuation or, for the restricted baseline on TEST-001, an added organizer phrase. The notice text places the punctuation immediately after the event title, while the frozen gold labels omit it. This is a possible annotation-boundary ambiguity under the verbatim-copy rule; the frozen labels and scores are retained as preregistered.

TEST-037 and TEST-038 contain two conflicting dates without a stated priority. The gold label requires `null`; the models select one listed date instead. These are substantive null-policy failures rather than formatting failures.

## Interpretation

For these cases, adding more general instructions did not eliminate the observed punctuation and conflict-resolution errors: the rewrite and oracle have the same five strict failures, and the restricted baseline has the same error IDs. The case patterns motivate a separate error-focused extension and a human audit of the punctuation convention. Do not revise the primary prompt or labels using these observed selection/test outcomes.
