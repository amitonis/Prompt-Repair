# Exploratory v3 result

**Scope:** post-hoc exploratory comparison on 12 owner-reviewed synthetic cases. Report raw counts only. This result is separate from the frozen primary study and does not support general claims.

| Arm | Correct records | Valid JSON | Valid schema |
| --- | ---: | ---: | ---: |
| Oracle baseline | 12/12 | 12/12 | 12/12 |
| Frozen v2 candidate | 12/12 | 12/12 | 12/12 |

Both arms returned correct records on all cases and valid JSON and schema on all 12. By category, both scored 3/3 on event-title boundary cases, 1/1 on the punctuation-review case, 4/4 across date cases, and 4/4 across venue cases.

The v2 candidate matched the baseline on this set. This is a raw-count result from 12 synthetic cases, not evidence of general performance. Keep it separate from the frozen primary results. Input, reviewed-label, baseline-prompt, and candidate-prompt hashes are recorded in `exploratory_v3_comparison.json` and match the local project artifacts.
