# Tier A reviewer prompt demos

**Scope:** development-only demonstrations using the fixed 10-case feedback and 10-case selection splits. No frozen-test data were used. These demos illustrate behavior; they are not a general prompt-repair evaluation.

| Demo | Before selection | Targeted patch | Full rewrite |
| --- | ---: | ---: | ---: |
| Vague extraction | 0/10 | 7/10, accepted | 5/10, accepted |
| Missing venue key | 0/10 | 8/10, accepted | 10/10, accepted |
| Wrong conflict rule | 0/10 | 0/10, rejected; no change | 9/10, accepted |

All accepted candidates kept valid JSON and schema on all 10 selection cases. The demos show that the tool can accept a useful targeted repair, that a full rewrite can perform better on some prompts, and that a targeted candidate can be rejected when it fails to improve selection accuracy. No method wins across all three examples.

The vague prompt's targeted repair changed only `output_format` and reached 7/10 on selection; its rewrite reached 5/10. For the missing-key prompt, targeted repair reached 8/10 and rewrite reached 10/10. For the wrong-conflict prompt, the targeted method produced no accepted change, while rewrite reached 9/10. The targeted method's detailed rejection trace should be reviewed from the Molab report before deciding whether to change the localizer/editor behavior.

Full report paths, field metrics, and issue counts from the Molab output are archived in `reviewer_prompt_demo_summary.json`. The Molab runtime retains complete raw generations and candidate traces.
