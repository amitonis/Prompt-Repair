# Reviewer prompt repair report

**Scope:** Tier A fixed notice task; feedback and selection development splits only. The frozen test split was not loaded.

- Run: `molab-demo-wrong-conflict-both-final`
- Mode: `both`
- Prompt input: `/marimo/promptrepair_runtime/examples/reviewer_prompts/demo_wrong_conflict_rule.json`
- Elapsed: 55.3 seconds
- Localizer ranking: output_format, constraints, instruction, context

## Before

| Split | Exact records | JSON valid | Schema valid |
| --- | ---: | ---: | ---: |
| Feedback | 0/10 | 1/10 | 1/10 |
| Selection | 0/10 | 2/10 | 2/10 |

## Candidate results

| Method | Accepted | Feedback before → after | Selection before → after | Section changed |
| --- | --- | ---: | ---: | --- |
| targeted | no | 0/10 → 0/10 | 0/10 → 0/10 | none (original retained) |
| rewrite | yes | 0/10 → 9/10 | 0/10 → 9/10 | instruction, context, constraints, output_format |

## Candidate decisions

### targeted

| Candidate | Accepted | Reason | Selection correct |
| --- | --- | --- | ---: |
| output_format | no | selection_acceptance_rule_not_met | 0/10 |
| constraints | no | selection_acceptance_rule_not_met | 0/10 |

Diff: `diff_targeted.patch`; prompt file: `prompt_after_targeted.json`.

### rewrite

| Candidate | Accepted | Reason | Selection correct |
| --- | --- | --- | ---: |
| 1 | yes | scored by selection rule | 9/10 |
| 2 | yes | scored by selection rule | 9/10 |

Diff: `diff_rewrite.patch`; prompt file: `prompt_after_rewrite.json`.

## Interpretation

Acceptance uses the development selection split: a repair must strictly improve exact-record accuracy and must not increase the number of schema-invalid responses. This report is a development result, not a test-set claim. In `both` mode, targeted patch and full rewrite are shown side by side; their comparison is descriptive.
